create definer = root@localhost view empinfo1 as
select `javaee2009`.`t_employees`.`employee_id` AS `employee_id`,
       `javaee2009`.`t_employees`.`first_name`  AS `first_name`,
       `javaee2009`.`t_employees`.`last_name`   AS `last_name`,
       `javaee2009`.`t_employees`.`salary`      AS `salary`
from `javaee2009`.`t_employees`;

